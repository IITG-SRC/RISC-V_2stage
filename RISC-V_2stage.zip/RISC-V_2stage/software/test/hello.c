#include <stdio.h>
#include <time.h>
#include <memory.h>
#include "uart_rdcyc.h"

int main()
{
	int i;
	long int t_beg = 3, t_end;
	
	for (i=0; i<100; i++);
    print_uart("Hello!\n"); 
    printf("Hello!\n"); 
	return 0;
}